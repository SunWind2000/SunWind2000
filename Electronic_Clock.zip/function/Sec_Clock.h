/*
 * Sec_Clock.h
 *
 *  Created on: 2021��5��30��
 *      Author: �����
 */

#ifndef FUNCTION_SEC_CLOCK_H_
#define FUNCTION_SEC_CLOCK_H_

extern void Sec_TimerA_Init();
extern void Display_Sec_Clock();
extern void Refresh_Sec_Clock();
extern void Start_Sec_Clock();
extern void Stop_Sec_Clock();



#endif /* FUNCTION_SEC_CLOCK_H_ */
