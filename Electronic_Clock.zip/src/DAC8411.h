/*
 * DAC8411.h
 *
 *  Created on: 2021��5��31��
 *      Author: �����
 */

#ifndef SRC_DAC8411_H_
#define SRC_DAC8411_H_



extern void DAC8411_Init(void);
extern void write2DAC8411(unsigned int bit_16);
extern void Open_Beep();
extern void Close_Beep();


#endif /* SRC_DAC8411_H_ */
