para = window.location.search;
var studID = para.split("=")[1];
//alert(studID);
//此处用jquery.js的AJAX
$.get("php/bookcart-list.php?studentID="+studID+"",function(data){
    var jsonObj=JSON.parse(data);
    //alert(jsonObj.length)
    var listHTML = '';
    for (var i=0; i<jsonObj.length; i++){
        listHTML += '<tr class="gradeX">' +
        '<td>'+jsonObj[i].name+'</td>' + 
        '<td>'+jsonObj[i].price+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].id+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].subject+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].publisher+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].author+'</td>' +
        '<td><button type="button" class="bk-margin-5 btn btn-danger"><a href="php/move-from-bookcart.php?bookID='+jsonObj[i].id+'"><i class="fa fa-trash-o"></i></a></button></td>' +
        '</tr>';
    }
    document.getElementById("test").innerHTML = listHTML;
});
$.get("php/book-bought-list.php?studentID="+studID+"",function(data){
    var jsonObj=JSON.parse(data);
    //alert(jsonObj.length)
    var listHTML = '';
    for (var i=0; i<jsonObj.length; i++){
        listHTML += '<tr class="gradeX">' +
        '<td>'+jsonObj[i].name+'</td>' + 
        '<td>'+jsonObj[i].price+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].id+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].subject+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].publisher+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].author+'</td>' +
        '<td><button type="button" class="bk-margin-5 btn btn-danger" disabled="disabled"><a href="php/move-from-bookcart.php?bookID='+jsonObj[i].id+'"><i class="fa fa-trash-o"></i></a></button></td>' +
        '</tr>';
    }
    document.getElementById("bought").innerHTML = listHTML;
});