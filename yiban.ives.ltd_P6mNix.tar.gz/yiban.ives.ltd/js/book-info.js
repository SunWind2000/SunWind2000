para = window.location.search;
var clgName = para.split("=")[1];
//此处用jquery.js的AJAX
$.get("php/book-list.php?clgName="+clgName+"",function(data){
    var jsonObj=JSON.parse(data);
    //alert(jsonObj.length)
    var listHTML = '';
    for (var i=0; i<jsonObj.length; i++){
        listHTML += '<tr class="gradeX">' +
        //'<td class="text-center"><i data-toggle="" class="fa fa-plus-square-o text-primary h5 m-none" style="cursor: pointer;"></i></td>' +
        '<td>'+jsonObj[i].name+'</td>' + 
        '<td>'+jsonObj[i].price+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].id+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].subject+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].publisher+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].author+'</td>' +
        '<td><button class="bk-margin-5 btn btn-primary" type="button"><a href="php/add-to-bookcart.php?bookid='+jsonObj[i].id+'"><i class="fa fa-shopping-cart"></i></a></button></td>' +
        '</tr>';
    }
    document.getElementById("test").innerHTML = listHTML;
});