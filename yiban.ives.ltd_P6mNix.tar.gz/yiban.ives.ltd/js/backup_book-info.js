para = window.location.search;
var clgName = para.split("=")[1];
//此处用jquery.js的AJAX
$.get("php/book-list.php?clgName="+clgName+"",function(data){
    var jsonObj=JSON.parse(data);
    //alert(jsonObj.length)
    var listHTML = '';
    for (var i=0; i<jsonObj.length; i++){
        listHTML += '<tr class="gradeX" id="list'+i+'">' +
        '<td>'+jsonObj[i].name+'</td>' + 
        '<td>'+jsonObj[i].price+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].id+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].subject+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].publisher+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].author+'</td>' +
        '<td><button type="button" class="bk-margin-5 btn btn-info btn-xs" id="subtract'+i+'"><i class="fa fa-minus" title="减少"></i></button><input style="width: 30px" type="text" id="text" disabled="disabled" value="0"/><button type="button" class="bk-margin-5 btn btn-info btn-xs" id="plus'+i+'"><i class="fa fa-plus" title="增加"></i></button></td>' +
        '</tr>';
    }
    document.getElementById("test").innerHTML = listHTML;
    
    window.onload=function(){
        var td1=document.getElementById("list'+i+'");
        var atd=td1.getElementByTagName("td");
        for(var n=0;n<atd.length;n++){
            fn1(atd[n]);
        }
        function fn1(atd){
            // var aBtn=atd.getElementByTagName("button");
            var inBtn=atd.getElementByTagName("input");
            var plus=atd.getElementById("plus'+i+'");
            var subtract=atd.getElementById("subtract'+i+'");
            var num=Number(inBtn.innerHTML);
            subtract.onclick=function(){
                if(num>0){
                    num--;
                    inBtn.innerHTML=num;
                }
            }
            plus.onclick=function(){
                num++;
                inBtn.innerHTML=num;
            }
        }
    }
//     var myApp = angular.module("app", ["ui.router"]);
// 	myApp.controller('cont',function($scope,$http,$state,jsonObj){
//         $scope.td=[];
//         for(var j=0;j<jsonObj.length;j++){
//             $scope[j].td = {name:jsonObj[j].name,math:0,price:parseInt(jsonObj[j].price),};
//         }
//         alert($scope.td);
//         $scope.jia=function(item){
// 			item.math++;
// 		}
// 		$scope.jian=function(item,index){
// 			if(item.math>0){
// 				item.math--;
// 			}else{
// 				item.math==1;
// 			}
// 		}
// 	});
    
});