$.get("php/2hand-book-list.php",function(data){
    var jsonObj=JSON.parse(data);
    //alert(jsonObj.length)
    var listHTML = '';
    for (var i=0; i<jsonObj.length; i++){
        listHTML += '<tr class="gradeX">' +
        //'<td class="text-center"><i data-toggle="" class="fa fa-plus-square-o text-primary h5 m-none" style="cursor: pointer;"></i></td>' +
        '<td>'+jsonObj[i].name+'</td>' + 
        '<td>'+jsonObj[i].price+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].subject+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].saler+'</td>' +
        '<td hidden="hidden">'+jsonObj[i].authorize+'</td>' +
        '<td>'+jsonObj[i].telephone+'</td>' +
        '</tr>';
    }
    document.getElementById("test").innerHTML = listHTML;
});