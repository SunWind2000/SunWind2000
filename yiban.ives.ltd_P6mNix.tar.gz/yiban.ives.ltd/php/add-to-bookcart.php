<?php
session_start();
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$bookID = $arr_query["bookid"];
$studentID = $_SESSION["studentID"];
$sql1 = "select * from bookcart where studentID='$studentID' and bookID='$bookID';";
$r = mysqli_query($conn,$sql1);
$resultCheck = mysqli_num_rows($r);
if($resultCheck==0){
    $sql2 = "INSERT INTO bookcart
             (studentID,status,bookID)
             VALUES
             ('$studentID','NO','$bookID')";
    $status2 = sql_insert($sql2);
    if($status2>0){
?>
        <script>
            alert("书籍加入购物车成功(^_^)")
            history.go(-1);
        </script>
<?php
    }
    else{
        echo "服务端错误或书籍库存量不足，加入购物车失败！";
    }
}
else{
?>
    <script>
        window.alert("这本书已经在你的购物车里了，再看看别的吧(^_^)");
        history.go(-1);
    </script>
<?php
}
?>