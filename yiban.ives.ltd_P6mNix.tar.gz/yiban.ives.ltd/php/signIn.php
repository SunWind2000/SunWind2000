<?php
header("Content-Type:text/html;charset=utf-8");

$studentID = $_POST["id"];
$pwd = $_POST["pwd"];
$identity = $_POST["identity"];
#echo $identity;
if($identity==null)
{
?>
    <script>window.alert("请选择登录身份");</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-login.html" />
<?php
}
else{
include 'dbConnector.php';
$sql = "SELECT * FROM user_information WHERE studentID='$studentID'";
$result = mysqli_query($conn,$sql);
$resultCheck = mysqli_num_rows($result);
if ($resultCheck==0) {
?>
    <script>window.alert("请先注册")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-register.html" />
<?php
} 
$sql1 = "SELECT * FROM user_information WHERE studentID='$studentID' and identity='$identity'";
$result1 = mysqli_query($conn,$sql1);
while($row=mysqli_fetch_assoc($result1)){
    #echo $row["studentID"]." ".$row["password"]." ".$row["identity"]."\n";
    #$flag1 = $row["studentID"]==$studentID;
    #echo "flag1:".$flag1;
    #$flag2 = $row["password"]==$pwd;
    #echo var_dump($row["password"])."\n"."-----";
    #echo var_dump($pwd);
    #$flag3 = $row["identity"]==$identity;
    #echo "flag3:".$flag3;
    #echo $flag1 and $flag2 and $flag3;
    if($row["studentID"]==$studentID and $row["identity"]=="student" and $row["password"]==$pwd){
        //设置cookie，避免未登录而进入首页
        session_start();
        $_SESSION["studentID"] = $studentID;
        echo "登录成功，准备跳转...";
?>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/index.php?identity=<?=$identity?>" />
<?php
    }
    elseif ($row["studentID"]==$studentID and $row["identity"]=="monitor" and $row["password"]==$pwd) {
        session_start();
        $_SESSION["studentID"] = $studentID;
        $_SESSION["identity"] = $identity;
        echo "登录成功，准备跳转...";
?>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/index-monitor.php?identity=<?=$identity?>" />
<?php
    }
    else{
?>
        <script>window.alert("用户名或密码或身份错误，请重试")</script>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-login.html" />
<?php
    }
}

$conn->close();
}
?>