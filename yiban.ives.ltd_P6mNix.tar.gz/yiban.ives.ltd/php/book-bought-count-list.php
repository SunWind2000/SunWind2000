<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
class BoughtBook{
    public $studentID;
    public $studentName;
    public $book_data;
}
$sql1 = "SELECT * FROM user_information WHERE identity='student'";
$result1 = sql_select($sql1);
if($result1){
    while($row=mysqli_fetch_assoc($result1)){
        $boughtBook = new BoughtBook();
        $boughtBook->studentID = $row["studentID"];
        $boughtBook->studentName = $row["username"];
        $sql2 = "SELECT * FROM purchase_list WHERE studentID='$boughtBook->studentID'";
        //echo $sql2;
        $result2 = sql_select($sql2);
        if($result2){
            while($row=mysqli_fetch_assoc($result2)){
                $book = new Book();
                $book->id = $row["bookID"];
                $sql3 = "SELECT * FROM book_list WHERE bookID='$book->id'";
                //echo $sql3;
                $result3 = sql_select($sql3);
                if($result3){
                    while($row=mysqli_fetch_assoc($result3)){
                        $book->subject = $row["className"];
                        $book->name = $row["bookName"];
                        $book->publisher = $row["publisher"];
                        $book->author = $row["author"];
                        $book->price = $row["price"];
                        $book->college = $row["class"];
                    }
                }
                //$book_data[] = $book;
                $boughtBook->book_data[] = $book;
            }
            //$json1 = json_encode($book_data);//把数据转换为JSON数据.
            //var_dump($json);
            //echo $json1;
        }
        if($boughtBook->book_data!=NULL){
            $data[] = $boughtBook;
        }
    }
    $json = json_encode($data);//把数据转换为JSON数据.
    //var_dump($json);
    echo $json;
}
?>