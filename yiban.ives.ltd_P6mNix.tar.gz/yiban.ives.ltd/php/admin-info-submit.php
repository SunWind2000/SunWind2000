<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$admin = new Admin();
$admin->username = $_POST["user"];
$admin->password = $_POST["pwd"];
$repwd = $_POST["repwd"];
$sql1 = "SELECT * FROM admin_information WHERE username='$admin->username'";
$r = sql_select($sql1);
$resultCheck = mysqli_num_rows($r);
//cho var_dump($resultCheck);
if($resultCheck!=0){
?>
    <script>
        window.alert("此用户名已被占用，试试别的吧(!_!)");
        history.go(-1);
    </script>
<?php
}
else{
    if($repwd!=$admin->password){
?>
        <script>
            window.alert("两次密码输入不一致，请重试(!_!)");
            history.go(-1);
        </script>
<?php
    }
    else{
        $userid = make_rand_id(10);
        $sql2 = "INSERT INTO admin_information (username,password,userid) VALUES ('$admin->username','$admin->password','$userid')";
        $r2 = sql_insert($sql2);
        if($r2){
?>
            <script>
                window.alert("管理员身份添加成功！(^_^)");
            </script>
            <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/add-admin.php" />
<?php
        }
    }
}
?>