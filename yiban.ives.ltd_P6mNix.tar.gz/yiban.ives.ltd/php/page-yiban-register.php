<!DOCTYPE html>
<html lang="en">
<?php
$token = isset($token) ? $token : $_GET['token'];
/**
 * 包含SDK
 */
require("classes/yb-globals.inc.php");

// 配置文件
require_once 'yiban-config.php';

//初始化配置信息，并获取token
$api = YBOpenApi::getInstance()->init($config['AppID'], $config['AppSecret'], $config['CallBack']);
$api->bind($token);
$userInfo = $api->request('user/me');
$yb_username = $userInfo["info"]["yb_username"];
$yb_userid = $userInfo["info"]["yb_userid"];
?>
	<head>
	
		<!-- Basic -->
    	<meta charset="UTF-8" />

		<title>关联易班账号 | DHU易购书</title>

		<!-- Mobile Metas -->
	    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		
		<!-- Import google fonts -->
        <link href='http://fonts.useso.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>
        
		<!-- Favicon and touch icons -->
		<link rel="shortcut icon" href="/assets/ico/favicon.ico" type="image/x-icon" />
		<link rel="apple-touch-icon" href="/assets/ico/apple-touch-icon.png" />
		<link rel="apple-touch-icon" sizes="57x57" href="/assets/ico/apple-touch-icon-57x57.png" />
		<link rel="apple-touch-icon" sizes="72x72" href="/assets/ico/apple-touch-icon-72x72.png" />
		<link rel="apple-touch-icon" sizes="76x76" href="/assets/ico/apple-touch-icon-76x76.png" />
		<link rel="apple-touch-icon" sizes="114x114" href="/assets/ico/apple-touch-icon-114x114.png" />
		<link rel="apple-touch-icon" sizes="120x120" href="/assets/ico/apple-touch-icon-120x120.png" />
		<link rel="apple-touch-icon" sizes="144x144" href="/assets/ico/apple-touch-icon-144x144.png" />
		<link rel="apple-touch-icon" sizes="152x152" href="/assets/ico/apple-touch-icon-152x152.png" />
		
	    <!-- start: CSS file-->
		
		<!-- Vendor CSS-->
		<link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
		<link href="/assets/vendor/skycons/css/skycons.css" rel="stylesheet" />
		<link href="/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
		
		<!-- Plugins CSS-->
		<link href="/assets/plugins/bootkit/css/bootkit.css" rel="stylesheet" />	
		
		<!-- Theme CSS -->
		<link href="/assets/css/jquery.mmenu.css" rel="stylesheet" />
		
		<!-- Page CSS -->		
		<link href="/assets/css/style.css" rel="stylesheet" />
		<link href="/assets/css/add-ons.min.css" rel="stylesheet" />
		
		<style>
			footer {
				display: none;
			}
		</style>
		
		<!-- end: CSS file-->	
	    
		
		<!-- Head Libs -->
		<script src="assets/plugins/modernizr/js/modernizr.js"></script>
		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->		
		
	</head>

	<body>
		<!-- Start: Content -->
		<div class="container-fluid content">
			<div class="row">
				<!-- Main Page -->
				<div id="content" class="col-sm-12 full">
					<div class="row">
						<div class="register-box">
							<div class="panel">
								<div class="panel-body">										
									<div class="header bk-margin-bottom-20 text-center">
									    <br>										
										<!--<img src="assets/img/logo.png" class="img-responsive" alt="" />-->
										<h4 style="text-align:center">欢迎关联易班账号！</h4>
									</div>									
									<form class="form-horizontal register" action="yiban-authorize-register.php" method="post">									
										<div class="bk-padding-left-20 bk-padding-right-20">
											<div class="form-group">
												<label>昵称</label>
												<input name="name" type="text" class="form-control" placeholder="请输入一个昵称"/ value="<?php echo $yb_username;?>" required/>
											</div>
											<div class="form-group">
												<label>学号</label>
												<input name="id" type="text" class="form-control" placeholder="请输入你的学号" required/>
											</div>
											<div class="form-group">
												<label>易班ID</label>
												<input readonly="readonly" name="yb_userid" type="text" class="form-control" value="<?php echo $yb_userid;?>"/>
											</div>
											<div class="form-group">
												<label>班级（格式如：电信类1501）</label>
												<input name="class" type="text" class="form-control" placeholder="请输入你的班级" required/>
											</div>	
											<div class="form-group">
												<div class="row">
													<div class="col-sm-6">
														<label>密码</label>
														<input name="pwd" type="password" class="form-control bk-margin-bottom-10" placeholder="请输入密码" required/>
													</div>
													<div class="col-sm-6">
														<label>确认密码</label>
														<input name="repwd" type="password" class="form-control bk-margin-bottom-10" placeholder="请确认密码" required/>
													</div>
												</div>
											</div>
											<div class="row bk-margin-top-20 bk-margin-bottom-10">
												<div class="col-sm-8">
													<div class="checkbox-custom checkbox-default">
														<input id="AgreeTerms" name="agreeterms" type="checkbox" required/>
														<label for="AgreeTerms">我同意 <a href="#">DHU易购书系统使用协议</a></label>
													</div>
												</div>
												<div class="col-sm-4 text-right">
													<button type="submit" class="btn btn-primary hidden-xs">注册</button>
													<button type="submit" class="btn btn-primary btn-block btn-lg visible-xs bk-margin-top-20">注册</button>
												</div>
											</div>											
											<div class="text-with-hr">
												<span>or</span>
											</div>											
											<p class="text-center">已经有账号? <a href="http://yiban.sunhaoyang.cn/page-login.html" style="color:blue">点我登录!</a>										
										</div>	
									</form>									
								</div>
							</div>							
							<p class="text-center text-muted">eBook-DHU易购书系统 <i class="fa fa-coffee"></i> Copyright <a href="http://blog.ives.ltd/" title="eBook" target="_blank">易班轻应用开发组-whiteGive</a></p>	
						</div>
					</div>
				</div>	
				<!-- End Main Page -->	
			</div>
		</div><!--/container-->
		
		
		<!-- start: JavaScript-->
		
		<!-- Vendor JS-->				
		<script src="/assets/vendor/js/jquery.min.js"></script>
		<script src="/assets/vendor/js/jquery-2.1.1.min.js"></script>
		<script src="/assets/vendor/js/jquery-migrate-1.2.1.min.js"></script>
		<script src="/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="/assets/vendor/skycons/js/skycons.js"></script>	
		
		<!-- Plugins JS-->
		<script src="/assets/plugins/bootkit/js/bootkit.js"></script>
		
		<!-- Theme JS -->		
		<script src="/assets/js/jquery.mmenu.min.js"></script>
		<script src="/assets/js/core.min.js"></script>
		
		<!-- Pages JS -->
		<script src="/assets/js/pages/page-register.js"></script>
		
		<!-- end: JavaScript-->
		
	</body>
	
</html>