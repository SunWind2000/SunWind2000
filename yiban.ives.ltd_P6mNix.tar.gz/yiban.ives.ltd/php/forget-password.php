<?php
header("Content-Type:text/html;charset=utf-8");
$id = $_POST["id"];
$new_pwd = $_POST["new_pwd"];
#echo $new_pwd;
$re_new_pwd = $_POST["re_new_pwd"];
if($new_pwd!==$re_new_pwd){
?>
    <script>window.alert("两次密码输入不一致，请重试！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/user-info.php" />
<?php
}
else{
    include('dbConnector.php');
    $sql1 = "SELECT * FROM user_information WHERE studentID=$id";
    $result1 = mysqli_query($conn,$sql1);
    $resultCheck = mysqli_num_rows($result1);
    if ($resultCheck!=0){
        $sql2 = "UPDATE user_information SET password='$new_pwd' WHERE studentID=$id;";
        mysqli_query($conn,$sql2);
?>
        <script>window.alert("<?php echo $id;?>密码重置成功，准备跳转...")</script>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/user-info.php" />
<?php
    }
    else{
        echo "服务器错误，重置密码失败..."."<br>".$conn->error;
?>
        <script>window.alert("请检查学号输入是否正确！")</script>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/user-info.php" />
<?php
    }
}
?>