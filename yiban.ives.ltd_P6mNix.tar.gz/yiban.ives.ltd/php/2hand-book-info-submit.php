<?php
header("Content-type:text/html;charset=utf-8");
session_start();
include("dbConnector.php");
$studentID = $_SESSION["studentID"];
$sql = "SELECT * FROM user_information WHERE studentID=$studentID and identity='student'";
$result = sql_select($sql);
$book = new TwohandBook();
while($row=mysqli_fetch_assoc($result)){
    $book->name = $_POST["bookName"];
    $book->price = $_POST["price"];
    $book->subject = $_POST["subject"];
    $book->saler = $row["username"];
    $book->telephone = $_POST["telephone"];
    $book->authorize = $row["yb_userid"];
    $book->id = make_rand_id();
}
$sql2 = "INSERT INTO twohand_book_list
        (bookName,price,subject,saler,telephone,authorize,bookID) 
        VALUES
        ('$book->name','$book->price','$book->subject','$book->saler','$book->telephone','$book->authorize','$book->id');";
//echo $sql2;
$status2 = sql_insert($sql2);
if($status2>0){
    echo "二手书信息上传成功...";
    header('location:http://yiban.ives.ltd/book-sale.php');  
}
else{
    echo "服务端错误，信息插入失败！";
}

