<?php
header("Content-Type:text/html;charset=utf-8");
$user = $_POST["name"];
$studentID = $_POST["id"];
$class = $_POST["class"];
$pwd = $_POST["pwd"];
$repwd = $_POST["repwd"];
if($user==null or $studentID==null or $class==null or $pwd==null or $repwd==null)
{
?>
    <script>window.alert("填写昵称、学号等信息不能为空！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-register.html" />
<?php
}
else{
if($pwd!==$repwd)
{
?>
    <script>window.alert("两次密码输入不一致，请重试！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-register.html" />
<?php    
}
else
{
    include('dbConnector.php');
    $sql = "SELECT * FROM user_information WHERE studentID='$studentID'";
    $result = mysqli_query($conn,$sql);
    $resultCheck = mysqli_num_rows($result);
    if ($resultCheck!=0)
    {
?>
        <script>window.alert("请检查学号输入是否错误！")</script>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-register.html" />
<?php
    }
    else
    {
        $sql = "INSERT INTO user_information
                (username,studentID,class,identity,password)
                VALUES
                ('".$user."','".$studentID."','".$class."','student','".$pwd."')";
        if($conn->query($sql)===TRUE)
        {
            echo "注册成功，正在准备跳转到登陆页面...";
?>
            <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-login.html" />
<?php
        }
        else
        {
            echo "服务器错误，注册失败..."."<br>".$conn->error;
        }
    }
}
}
?>