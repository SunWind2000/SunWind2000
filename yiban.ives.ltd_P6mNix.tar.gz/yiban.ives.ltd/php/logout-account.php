<?php
header("Content-Type:text/html;charset=utf-8");
$id = $_POST["id"];
$pwd = $_POST["pwd"];
include('dbConnector.php');
$sql1 = "SELECT * FROM user_information WHERE studentID=$id and password='$pwd'";
$result1 = mysqli_query($conn,$sql1);
$resultCheck = mysqli_num_rows($result1);
if($resultCheck==0){
?>
    <script>window.alert("请检查学号密码输入是否正确，若忘记密码可以在个人信息页面查看！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/user-info.php" />
<?php
}
else{
    $sql2 = "DELETE FROM user_information WHERE studentID=$id and password='$pwd'";
    mysqli_query($conn,$sql2);
    echo "用户".$id."的账户注销成功，关闭浏览器后退出系统...";
}
?>