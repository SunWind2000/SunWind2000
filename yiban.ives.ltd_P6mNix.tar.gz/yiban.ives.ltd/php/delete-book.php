<?php
header("Content-Type:text/html;charset=utf-8");
include('dbConnector.php');
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$bookID = $arr_query["bookid"];
$sql1 = "DELETE FROM book_list WHERE bookID='$bookID';";
$r = sql_delete($sql1);
if($r>0){
?>
    <script>window.alert("书籍信息删除成功！")</script>
<?php
    header('location:http://yiban.ives.ltd/book-info-upload.html');
}
else{
?>
    <script>window.alert("服务器异常，删除信息失败！")</script>
<?php    
    header('location:http://yiban.ives.ltd/book-info-upload.html');
}
?>