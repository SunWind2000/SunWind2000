<?php
header("Content-Type:text/html;charset=utf-8");
$user = $_POST["name"];
$studentID = $_POST["id"];
$yb_userid = $_POST["yb_userid"];
echo $yb_userid;
$class = $_POST["class"];
$pwd = $_POST["pwd"];
$repwd = $_POST["repwd"];
if($user==null or $studentID==null or $yb_userid==null or $class==null or $pwd==null or $repwd==null)
{
?>
    <script>window.alert("填写昵称、学号等信息不能为空！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/php/page-yiban-register.php" />
<?php
}
else{
if($pwd!==$repwd)
{
?>
    <script>window.alert("两次密码输入不一致，请重试！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/php/page-yiban-register.php" />
<?php    
}
else
{
    include('dbConnector.php');
    $sql1 = "SELECT * FROM user_information WHERE studentID=$studentID";
    $result1 = mysqli_query($conn,$sql1);
    $resultCheck = mysqli_num_rows($result1);
    if ($resultCheck!=0)
    {
        $sql2 = "UPDATE user_information SET yb_userid=$yb_userid WHERE studentID=$studentID";
        mysqli_query($conn,$sql2);
        echo "用户".$studentID."关联易班账号".$yb_userid."成功，准备跳转回登录页面...";
?>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-login.html" />
<?php
    }
    else
    {
        $sql3 = "INSERT INTO user_information
                (username,studentID,class,identity,password,yb_userid)
                VALUES
                ('".$user."','".$studentID."','".$class."','student','".$pwd."','".$yb_userid."')";
        if($conn->query($sql3)===TRUE)
        {
            echo "用户".$studentID."首次注册成功，正在准备跳转到登录页面...";
?>
            <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-login.html" />
<?php
        }
        else
        {
            echo "服务器错误，注册失败..."."<br>".$conn->error;
        }
    }
}
}
?>