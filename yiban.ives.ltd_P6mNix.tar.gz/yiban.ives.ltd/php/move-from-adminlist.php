<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$adminID = $arr_query["adminID"];
if($adminID==="wdeft24bgy"){
?>
    <script>
        window.alert("超级管理员身份不能删除！")
        history.go(-1);
    </script>
<?php
}
else{
$sql = "DELETE FROM admin_information WHERE userid='$adminID'";
$r = sql_delete($sql);
if($r>0){
?>
    <script>window.alert("管理员<?php echo $adminID?>信息移除成功！");</script>
<?php
    header("location:http://yiban.ives.ltd/add-admin.php");
}
else{
?>
    <script>window.alert("服务器异常，管理员<?php echo $adminID?>信息移除失败！请联系系统管理员");</script>
<?php
    header("location:http://yiban.ives.ltd/add-admin.php");
}
}
?>