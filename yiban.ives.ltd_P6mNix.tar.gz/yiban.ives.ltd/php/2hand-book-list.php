<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$url = curPageURL();
//echo($url);
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$yb_userid = $arr_query["yb_userid"];
//echo var_dump($yb_userid);
if($yb_userid==NULL){
$sql = "SELECT * FROM twohand_book_list";
$result = sql_select($sql);
if($result){
    while($row=mysqli_fetch_assoc($result)){
        $book = new TwohandBook();
        $book->name = $row["bookName"];
        $book->price = $row["price"];
        $book->subject = $row["subject"];
        $book->saler = $row["saler"];
        $book->telephone = $row["telephone"];
        $book->authorize = $row["authorize"];
        $book->id = $row["bookID"];
        $data[] = $book;
    }
    $json = json_encode($data);//把数据转换为JSON数据.
    //var_dump($json);
    echo $json;
}
else{
    echo 0;
}
}
if($yb_userid!=NULL){
$sql = "SELECT * FROM twohand_book_list WHERE authorize='$yb_userid'";
//echo $sql;
$result = sql_select($sql);
if($result){
    while($row=mysqli_fetch_assoc($result)){
        $book = new TwohandBook();
        $book->name = $row["bookName"];
        $book->price = $row["price"];
        $book->subject = $row["subject"];
        $book->saler = $row["saler"];
        $book->telephone = $row["telephone"];
        $book->authorize = $row["authorize"];
        $book->id = $row["bookID"];
        $data[] = $book;
    }
    $json = json_encode($data);//把数据转换为JSON数据.
    //var_dump($json);
    echo $json;
}
else{
    echo 0;
}
}
?>
