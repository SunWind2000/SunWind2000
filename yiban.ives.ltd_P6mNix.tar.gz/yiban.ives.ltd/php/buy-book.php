<?php
session_start();
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$studentID = $_SESSION["studentID"];
$sql1 = "select * from bookcart where studentID='$studentID'";
$r1 = mysqli_query($conn,$sql1);
$resultCheck = mysqli_num_rows($r1);
if($resultCheck!=0){
    while($row=mysqli_fetch_assoc($r1)){
        $bookID = $row["bookID"];
        $sql2 = "INSERT INTO purchase_list
                (studentID,bookID)
                VALUES
                ('$studentID','$bookID')";
        $sql3 = "DELETE FROM bookcart WHERE studentID='$studentID' and bookID='$bookID'";
        $r2 = sql_insert($sql2);
        $r3 = sql_delete($sql3);
    }
?>
    <script>alert("购买成功，购物车已清空(^_^)");</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/book-cart.php?studentID=<?php echo $studentID;?>" />
<?php
}
else {
?>
    <script>alert("您还未购买任何书籍哦，去书目清单看一下再来提交吧");</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/book-cart.php?studentID=<?php echo $studentID;?>" />
<?php
}
?>