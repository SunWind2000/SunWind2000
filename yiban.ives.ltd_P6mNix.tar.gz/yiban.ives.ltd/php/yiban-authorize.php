<?php
	/**
	 * 网站接入使用Auth认证接口进行授权
	 * 授权流程先通过浏览器重定向到授权服务器取得授权码（code）后
	 * 再从服务器使用接口调用获取到对应用户的访问令牌
	 * 
	 */
    

	/**
	 * 包含SDK
	 */
	require("classes/yb-globals.inc.php");

	//配置文件
	require_once 'yiban-config.php';
	
	//初始化
	$api = YBOpenApi::getInstance()->init($config['AppID'], $config['AppSecret'], $config['CallBack']);
	$au  = $api->getAuthorize();
	
	//网站接入获取access_token，未授权则跳转至授权页面
	$info = $au->getToken();
	if(!$info['status']) {//授权失败
	    echo $info['msg'];
	    die;
	}
	$token = $info['token'];//网站接入获取的token
	
?>
<html>
<body>
	<p>
	    <?php 
	    if (isset($token)&&$token){
	        $api->bind($token);
	        $userArray = $api->request('user/me');
	        $yb_userid = $userArray["info"]["yb_userid"];
	        #echo $yb_userid;
	        include("dbConnector.php");
	        $sql = "SELECT * FROM user_information WHERE identity='student' and yb_userid='$yb_userid'" ;
	        $result = mysqli_query($conn,$sql);
            $resultCheck = mysqli_num_rows($result);
            if ($resultCheck==0){
	    ?>
	            <script>alert("首次使用易班登录，请先关联学号");</script>
	            <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/php/page-yiban-register.php?token=<?=$token?>" />
	    <?php 
	        }
	        else{
	            while($row=mysqli_fetch_assoc($result)){
	                session_start();
                    $_SESSION["studentID"] = $row["studentID"];
	                echo "易班用户".$yb_userid.":".$row["username"]."授权成功，准备跳转...";
	    ?>
	                <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/index.php" />
	                <!--录入班级管理员信息时yb_userid一项必须为NULL！！！！！，提醒自己-->
	    <?php
	            }
	        }
	    }
	    ?>
	</p>
	<!--<a href="apitest.php?token=<$token?>">点击查看通用接口调用测试页面</a>-->
	<!--<a target="_blank" href="https://o.yiban.cn/wiki/index.php?page=%E7%BD%91%E7%AB%99%E6%8E%A5%E5%85%A5%E5%BC%80%E5%8F%91%E6%8C%87%E5%8D%97">网站接入开发指南</a>-->
</body>
</html>