<?php
session_start();
include("dbConnector.php");
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$noticeID = $arr_query["noticeID"];
$theme = $_POST["theme"];
$contents = $_POST["content"];
$date = date('Y-m-d', time());
$sql = "UPDATE notice_list SET theme='$theme',contents='$contents',date='$date' WHERE id='$noticeID'";
$r = sql_update($sql);
if($r){
?>
    <script>
        window.alert("公告信息更改成功(^_^)！");
    </script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/notice-list.html" />
<?php
}
else {
?>
    <script>
        window.alert("数据库错误，公告信息更新失败，请重试！");
        history.go(-1);
    </script>
<?php
}
?>