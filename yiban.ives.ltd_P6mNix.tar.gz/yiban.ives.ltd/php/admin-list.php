<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$sql = "SELECT * FROM admin_information";
$result = sql_select($sql);
if($result){
    while($row=mysqli_fetch_assoc($result)){
        $admin = new Admin();
        $admin->username = $row["username"];
        $admin->password = $row["password"];
        $admin->userid = $row["userid"];
        $data[] = $admin;
    }
    $json = json_encode($data);//把数据转换为JSON数据.
    //var_dump($json);
    echo $json;
}
else{
    echo 0;
}
?>