<?php
session_start();
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$bookID = $arr_query["bookID"];
$studentID = $_SESSION["studentID"];
$sql = "DELETE FROM bookcart WHERE studentID='$studentID' and bookID='$bookID'";
//echo $sql;
$r = sql_delete($sql);
if($r>0){
?>
    <script>window.alert("书籍移出购物车成功！");</script>
<?php
    header("location:http://yiban.ives.ltd/book-cart.php?studentID=$studentID");
}
else{
?>
    <script>window.alert("服务器异常，书籍移出购物车失败！请联系系统管理员");</script>
<?php
    header("location:http://yiban.ives.ltd/book-cart.php?studentID=$studentID");
}
?>