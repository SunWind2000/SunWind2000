<?php
header("Content-type:text/html; charset=utf-8");
//数据库连接信息
$server = "127.0.0.1";
$username = "root";
$password = "Sunhaoyang123";
$dbName = "BookingSystem";

//直接连接数据库外部变量$conn
try{
    $conn = new mysqli($server,$username,$password,$dbName);
    #echo "数据库连接成功\n";
}
catch(PDOException $e){
    echo $e -> getMessage();
}

//书籍信息结构体
class Book{
    public $id;
    public $subject;
    public $name;
    public $publisher;
    public $author;
    public $price;
    public $college;
    public $classid;
    public $number;
}
//二手书信息结构体
class TwohandBook{
    public $id;
    public $name;
    public $price;
    public $subject;
    public $saler;
    public $telephone;
    public $authorize;
}
//用户信息结构体
class User{
    public $username;
    public $studentID;
    public $class;
    public $identity;
    public $password;
    public $yb_userid;
    public $status;
    public $img_link;
}
//管理员信息结构体
class Admin{
    public $username;
    public $password;
}
//通知信息结构体
class Notice{
    public $theme;
    public $contents;
    public $date_;
    public $id;
}

//数据库连接
function sql_connect()
{
    $server = "127.0.0.1";
    $username = "root";
    $password = "Sunhaoyang123";
    $dbName = "BookingSystem";
    try{
    $conn = mysqli_connect($server,$username,$password,$dbName);
    mysqli_set_charset($conn,"utf8");
    //$charset=mysqli_character_set_name($conn);
    //echo $charset;
    //echo "数据库连接成功\n";
    //mysqli_query($conn,"SET NAMES 'utf8'");
    return $conn;
    }
    catch(PDOException $e){
        echo $e -> getMessage();
        return -1;
    }
}
//数据查询
function sql_select($sql)
{
    $con = sql_connect();
    $r=mysqli_query($con,$sql);
    if($r!=false){
        return $r;
    }
    else{
        return 0;
    }
    mysqli_close($con);
}
//数据删除
function sql_delete($sql)
{
    $con = sql_connect();
    if(mysqli_query($con,$sql)){
        return 1;
    }
    else{
        return -1;
    }
    mysqli_close($con);
}
//数据增添
function sql_insert($sql)
{
    $con = sql_connect();
    if(mysqli_query($con,$sql)){
        return 1;
    }
    else{
        return 0;
    }
    mysqli_close($con);
}
//数据修改
function sql_update($sql)
{
    $con = sql_connect();
    if(mysqli_query($con,$sql)){
        return 1;
    }
    else{
        return -1;
    }
    mysqli_close($con);
}

//获取当前PHP页面的URL
function curPageURL() 
{
    $pageURL = 'http';
    if ($_SERVER["HTTPS"] == "on") 
    {
        $pageURL .= "s";
    }
    $pageURL .= "://";
    if ($_SERVER["SERVER_PORT"] != "80") 
    {
        $pageURL .= $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
    } 
    else
    {
        $pageURL .= $_SERVER["SERVER_NAME"] . $_SERVER["REQUEST_URI"];
    }
    return $pageURL;
}

//获取URL中的参数列表
function convertUrlQuery($query)
{
    $queryParts = explode('&', $query);
    $params = array();
    foreach ($queryParts as $param) {
        $item = explode('=', $param);
        $params[$item[0]] = $item[1];
    }
  return $params;
}

//生成随机字符
function make_rand_id( $length = 10 )
{
    // 密码字符集，可任意添加你需要的字符
    $chars = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 
    'i', 'j', 'k', 'l','m', 'n', 'o', 'p', 'q', 'r', 's', 
    't', 'u', 'v', 'w', 'x', 'y','z', 'A', 'B', 'C', 'D', 
    'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L','M', 'N', 'O', 
    'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y','Z', 
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    // 在 $chars 中随机取 $length 个数组元素键名
    $keys = array_rand($chars, $length); 
    $rand_id = '';
    for($i = 0; $i < $length; $i++)
    {
        // 将 $length 个数组元素连接成字符串
        $rand_id .= $chars[$keys[$i]];
    }
    return $rand_id;
}
?>