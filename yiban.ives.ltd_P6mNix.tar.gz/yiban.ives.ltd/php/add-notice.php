<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$date = date('Y-m-d', time());
//echo $date;
$contents = $_POST["content"];
$noticeID = make_rand_id(10);
$theme = $_POST["theme"];
if($contents!=NULL and $theme!=NULL){
    $sql = "INSERT INTO notice_list (theme,contents,date,id) VALUES ('$theme','$contents','$date','$noticeID')";
    echo $sql;
    $r = sql_insert($sql);
    if($r){
?>
    <script>
        alert("发布成功！");
        history.go(-1);
    </script>
<?php
    }
}
else{
?>
    <script>
        alert("标题或内容不能为空！");
        history.go(-1);
    </script>
<?
}
?>