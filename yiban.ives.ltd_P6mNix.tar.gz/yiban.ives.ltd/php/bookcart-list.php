<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$url = curPageURL();
//echo $url;
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
//var_dump($arr_query["clgName"]);
$studentID = $arr_query["studentID"];
$sql1 = "SELECT * FROM bookcart WHERE studentID='$studentID';";
$result1 = sql_select($sql1);
if($result1){
    while($row=mysqli_fetch_assoc($result1)){
        $book = new Book();
        //$book->name = $row["bookName"];
        //$book->price = $row["price"];
        $book->id = $row["bookID"];
        $sql2 = "SELECT * FROM book_list WHERE bookID='$book->id';";
        $result2 = sql_select($sql2);
        if($result2){
            while($row=mysqli_fetch_assoc($result2)){
                $book->subject = $row["className"];
                $book->name = $row["bookName"];
                $book->publisher = $row["publisher"];
                $book->author = $row["author"];
                $book->price = $row["price"];
                $book->college = $row["class"];
            }
        }
        $data[] = $book;
        //var_dump($book);
    }
    $json = json_encode($data);//把数据转换为JSON数据.
    //var_dump($json);
    echo $json;
}
else{
    echo 0;
}
?>