<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$noticeID = $arr_query["noticeID"];
$sql = "DELETE FROM notice_list WHERE id='$noticeID'";
//echo $sql;
$r = sql_delete($sql);
if($r>0){
?>
    <script>window.alert("公告删除成功！");</script>
<?php
    header("location:http://yiban.ives.ltd/notice-list.html");
}
else{
?>
    <script>window.alert("服务器异常，公告删除失败！请联系系统管理员");</script>
<?php
    header("location:http://yiban.ives.ltd/notice-list.html");
}
?>