<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
include('dbConnector.php');
$studentID = $_SESSION["studentID"];
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$bookID = $arr_query["bookid"];
$sql1 = "DELETE FROM twohand_book_list WHERE bookID='$bookID';";
$r = sql_delete($sql1);
if($r>0){
?>
    <script>window.alert("书籍信息删除成功！")</script>
<?php
    header("location:http://yiban.ives.ltd/book-sale.php?studentID=$studentID");
}
else{
?>
    <script>window.alert("服务器异常，删除信息失败！")</script>
<?php    
    header("location:http://yiban.ives.ltd/book-sale.php?studentID=$studentID");
}
?>