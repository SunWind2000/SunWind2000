<?php
header("Content-Type:text/html;charset=utf-8");

include 'dbConnector.php';
$admin = new Admin();
$admin->username = $_POST["id"];
$admin->password = $_POST["pwd"];
$sql = "SELECT * FROM admin_information WHERE username='$admin->username' and password='$admin->password';";
//echo $sql;
$r = sql_select($sql);
$resultCheck = mysqli_num_rows($r);
if ($resultCheck==0) {
?>
    <script>window.alert("用户名或密码错误，请重试！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-login-admin.html" />
<?php
}
else {
    session_start();
    $_SESSION["adminID"] = $admin->username;
    echo "登录成功，准备跳转...";
    header('location:http://yiban.ives.ltd/index-admin.php');
}
?>