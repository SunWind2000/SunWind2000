<?php
header("Content-Type:text/html;charset=utf-8");
$id = $_POST["id"];
$new_pwd = $_POST["new_pwd"];
#echo $new_pwd;
$re_new_pwd = $_POST["re_new_pwd"];
if($new_pwd!==$re_new_pwd){
?>
    <script>window.alert("两次密码输入不一致，请重试！")</script>
    <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/admin-info.php" />
<?php
}
else{
    include('dbConnector.php');
    $sql1 = "SELECT * FROM admin_information WHERE username='$id';";
    $r1 = sql_select($sql1);
    $resultCheck = mysqli_num_rows($r1);
    if ($resultCheck!=0){
        $sql2 = "UPDATE admin_information SET password='$new_pwd' WHERE username='$id';";
        if(sql_update($sql2)>0){
?>
            <script>window.alert("<?php echo $id;?>密码重置成功，准备跳转...")</script>
            <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/admin-info.php" />
<?php
        }
        else{
            echo "服务器错误，重置密码失败..."."<br>".sql_update($sql2);
        }
    }
    else{
?>
        <script>window.alert("请检查学号输入是否正确！")</script>
        <meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/admin-info.php" />
<?php
    }
}
?>        