<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$studentID = $arr_query["studentID"];
if($studentID!=NULL){
$sql = "DELETE FROM purchase_list WHERE studentID='$studentID'";
//echo $sql;
$r = sql_delete($sql);
if($r>0){
?>
    <script>window.alert("购书信息移除成功！");</script>
<?php
    header("location:http://yiban.ives.ltd/purchase-count.php");
}
else{
?>
    <script>window.alert("服务器异常，购书信息移除失败！请联系系统管理员");</script>
<?php
    header("location:http://yiban.ives.ltd/purchase-count.php");
}
}
if($studentID==NULL){
$sql = "DELETE FROM purchase_list";
//echo $sql;
$r = sql_delete($sql);
if($r>0){
?>
    <script>window.alert("购书信息移除成功！");</script>
<?php
    header("location:http://yiban.ives.ltd/purchase-count.php");
}
else{
?>
    <script>window.alert("服务器异常，购书信息移除失败！请联系系统管理员");</script>
<?php
    header("location:http://yiban.ives.ltd/purchase-count.php");
}
}
?>