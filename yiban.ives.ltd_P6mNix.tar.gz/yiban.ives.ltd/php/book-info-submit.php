<?php
header("Content-type:text/html;charset=utf-8");
include("dbConnector.php");
$book = new Book();
$book->name = $_POST["bookName"];
$book->subject = $_POST["className"];
$book->publisher = $_POST["publisher"];
$book->author = $_POST["author"];
$book->id = $_POST["bookID"];
$book->price = $_POST["price"];
$book->classid = $_POST["classid"];
$book->number = $_POST["num"];
//echo $book->id;
if($book->classid=="li"){$book->college = "理学院";}
if($book->classid=="renwen"){$book->college = "人文学院";}
if($book->classid=="fangzhi"){$book->college = "纺织学院";}
if($book->classid=="fuzhuang"){$book->college = "服装学院";}
if($book->classid=="guanli"){$book->college = "管理学院";}
if($book->classid=="jixie"){$book->college = "机械学院";}
if($book->classid=="xinxi"){$book->college = "信息学院";}
if($book->classid=="huasheng"){$book->college = "化工与生物学院";}
if($book->classid=="cailiao"){$book->college = "材料学院";}
if($book->classid=="huanjing"){$book->college = "环境学院";}
if($book->classid=="qita"){$book->college = "其他";}

$sql1 = "SELECT * FROM book_list WHERE bookID='$book->id'";
//echo $sql1;
$r = mysqli_query($conn,$sql1);
$resultCheck = mysqli_num_rows($r);
if($resultCheck!=0){
?>
    <script>window.alert("该书籍信息已存在，不能重复插入！");</script>
<?php
    header('location:http://yiban.ives.ltd/book-info-upload.html');
}
else{
    $sql2 = "INSERT INTO book_list
        (className,bookName,publisher,author,bookID,price,class,classid,num) 
        VALUES
        ('$book->subject','$book->name','$book->publisher','$book->author','$book->id','$book->price','$book->college','$book->classid',$book->number);";
    //echo $sql2;
    $status2 = sql_insert($sql2);
    if($status2>0){
        echo "书籍信息插入成功...";
        header('location:http://yiban.ives.ltd/book-info-upload.html');  
    }
    else{
        echo "服务端错误，信息插入失败！";
    }
}
?>