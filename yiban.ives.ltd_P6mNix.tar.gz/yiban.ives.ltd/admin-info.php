<!DOCTYPE html>
<html lang="en">
<?php
session_start();
include("php/dbConnector.php");
if(isset($_SESSION["adminID"])){
	$adminID = $_SESSION["adminID"];
	$sql = "SELECT * FROM admin_information WHERE username='$adminID';";
	$result = mysqli_query($conn,$sql);
?>
<head>
	<!-- Basic -->
	<meta charset="UTF-8" />

	<title>DHU易购书 | 个人信息页</title>
  
	<!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	
	<!-- Import google fonts -->
    <link href='http://fonts.useso.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>
    
	<!-- Favicon and touch icons -->
	<link rel="shortcut icon" href="assets/ico/favicon.ico" type="image/x-icon" />
	<link rel="apple-touch-icon" href="assets/ico/apple-touch-icon.png" />
	<link rel="apple-touch-icon" sizes="57x57" href="assets/ico/apple-touch-icon-57x57.png" />
	<link rel="apple-touch-icon" sizes="72x72" href="assets/ico/apple-touch-icon-72x72.png" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/ico/apple-touch-icon-76x76.png" />
	<link rel="apple-touch-icon" sizes="114x114" href="assets/ico/apple-touch-icon-114x114.png" />
	<link rel="apple-touch-icon" sizes="120x120" href="assets/ico/apple-touch-icon-120x120.png" />
	<link rel="apple-touch-icon" sizes="144x144" href="assets/ico/apple-touch-icon-144x144.png" />
	<link rel="apple-touch-icon" sizes="152x152" href="assets/ico/apple-touch-icon-152x152.png" />
	
    <!-- start: CSS file-->
	
	<!-- Vendor CSS-->
	<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/vendor/skycons/css/skycons.css" rel="stylesheet" />
	<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="assets/vendor/css/pace.preloader.css" rel="stylesheet" />
	
	<!-- Plugins CSS-->
	<link href="assets/plugins/bootkit/css/bootkit.css" rel="stylesheet" />
	<link href="assets/plugins/jquery-ui/css/jquery-ui-1.10.4.min.css" rel="stylesheet" />					
	
	<!-- Theme CSS -->
	<link href="assets/css/jquery.mmenu.css" rel="stylesheet" />
	
	<!-- Page CSS -->		
	<link href="assets/css/style.css" rel="stylesheet" />
	<link href="assets/css/add-ons.min.css" rel="stylesheet" />
	
	<!-- end: CSS file-->	
    
	
	<!-- Head Libs -->
	<script src="assets/plugins/modernizr/js/modernizr.js"></script>
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->		
	
</head>

<body>
<?php while($row=mysqli_fetch_assoc($result)){?>
<!--个人信息展示部分-->
<div class="row">					
	<div class="col-lg-12">                           
		<div class="panel panel-default bk-bg-white">                                
			<div class="panel-heading bk-bg-white">
				<h6><i class="fa fa-table red"></i><span class="break"></span>当前用户信息</h6>
				<div class="panel-actions">
				</div>
			</div>										
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-hover">
						<thead>
							<tr>
								<th>标题</th>
								<th>内容</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>
									用户名
								</td>
								<td><?php echo $row["username"];?></td>
							</tr>
							<tr>
								<td>
									登录身份
								</td>
								<td>admin</td>
							</tr>
							<tr>
								<td>
									密码
								</td>
								<td><?php echo $row["password"];?></td>
							</tr>
							<tr>
								<td>
									ID
								</td>
								<td><?php echo $row["userid"];?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>                 
	</div>					
</div>
<!--个人信息展示部分结束-->

<div class="row">
<!--修改密码表单部分-->
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	<form id="form" action="php/forget-password-admin.php" class="form-horizontal" method="post">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6><i class="fa  fa-check-circle-o bk-fg-warning"></i>修改密码</h6>									
				<div class="panel-actions">
				</div>
			</div>
			<div class="panel-body">
			    <div class="form-group">
					<label class="col-sm-3 control-label">用户名 <span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="text" name="id" class="form-control" placeholder="请输入管理员用户名" required/>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">新密码 <span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="password" name="new_pwd" class="form-control" placeholder="请输入新密码" required/>
					</div>
				</div>
		        <div class="form-group">
					<label class="col-sm-3 control-label">确认新密码 <span class="required">*</span></label>
					<div class="col-sm-9">
						<input type="password" name="re_new_pwd" class="form-control" placeholder="请再次输入新密码" required/>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-9 col-sm-offset-3">
						<button class="bk-margin-5 btn btn-info" type="submit">提交</button>
						<button type="reset" class="bk-margin-5 btn btn-default">重置</button>
					</div>
				</div>
			</div>									
		</div>
	</form>
</div>
<!--修改密码表单部分结束-->
</div>

<?php } ?>
</body>
<?php }else{echo "请先登录";} ?>
</html>