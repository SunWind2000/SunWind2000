<?php
    /**
	 *易班授权接入 配置文件(网站接入)
	 */
	$config = array(
	    'AppID'     => '88c9662cd44c6b6d',  //此处填写你的appid
	    'AppSecret' => '89a5600243ecd9d7326ef7e9e8bae082',  //此处填写你的AppSecret
	    'CallBack'  => 'yiban-authorize.php',  //此处填写你的授权回调地址
	);
?>