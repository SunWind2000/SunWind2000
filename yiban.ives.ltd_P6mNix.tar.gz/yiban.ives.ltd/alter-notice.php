<!DOCTYPE html>

<html lang="en">
<?php
session_start();
include("php/dbConnector.php");
$url = curPageURL();
$arr = parse_url($url);
$arr_query = convertUrlQuery($arr['query']);
$noticeID = $arr_query["noticeID"];
?>
	<head>
	
		<!-- Basic -->
    	<meta charset="UTF-8" />

		<title>Editors | Fire - Admin Template</title>
		
		<!-- Mobile Metas -->
	    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		
		<!-- Import google fonts -->
        <link href='http://fonts.useso.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>
        
		<!-- Favicon and touch icons -->
		<link rel="shortcut icon" href="assets/ico/favicon.ico" type="image/x-icon" />
		<link rel="apple-touch-icon" href="assets/ico/apple-touch-icon.png" />
		<link rel="apple-touch-icon" sizes="57x57" href="assets/ico/apple-touch-icon-57x57.png" />
		<link rel="apple-touch-icon" sizes="72x72" href="assets/ico/apple-touch-icon-72x72.png" />
		<link rel="apple-touch-icon" sizes="76x76" href="assets/ico/apple-touch-icon-76x76.png" />
		<link rel="apple-touch-icon" sizes="114x114" href="assets/ico/apple-touch-icon-114x114.png" />
		<link rel="apple-touch-icon" sizes="120x120" href="assets/ico/apple-touch-icon-120x120.png" />
		<link rel="apple-touch-icon" sizes="144x144" href="assets/ico/apple-touch-icon-144x144.png" />
		<link rel="apple-touch-icon" sizes="152x152" href="assets/ico/apple-touch-icon-152x152.png" />
		
	    <!-- start: CSS file-->
		
		<!-- Vendor CSS-->
		<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
		<link href="assets/vendor/skycons/css/skycons.css" rel="stylesheet" />
		<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
		<link href="assets/vendor/css/pace.preloader.css" rel="stylesheet" />
		
		<!-- Plugins CSS-->
		<link href="assets/plugins/bootkit/css/bootkit.css" rel="stylesheet" />
		<link href="assets/plugins/fullcalendar/css/fullcalendar.css" rel="stylesheet" />				
		<link href="assets/plugins/summernote/css/summernote.css" rel="stylesheet" />
		<link href="assets/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css" rel="stylesheet" />
		
		<!-- Theme CSS -->
		<link href="assets/css/jquery.mmenu.css" rel="stylesheet" />
		
		<!-- Page CSS -->		
		<link href="assets/css/style.css" rel="stylesheet" />
		<link href="assets/css/add-ons.min.css" rel="stylesheet" />
		
		<!-- end: CSS file-->	
	    
		
		<!-- Head Libs -->
		<script src="assets/plugins/modernizr/js/modernizr.js"></script>
		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->		
		
	</head>
	
	<body>
	<?php
	if(isset($_SESSION["adminID"])){
		$adminID = $_SESSION["adminID"];
		$sql = "SELECT * FROM admin_information WHERE username='$adminID'";
		$result = mysqli_query($conn,$sql);
		while($row=mysqli_fetch_assoc($result)){
	?>
        <div class="row">
			<div class="col-xs-12">
				<div class="panel panel-default">
					<div class="panel-heading bk-bg-white">
						<h6><i class="fa fa-edit red"></i>Markdown编辑器 | 编辑公告</h6>						
						<div class="panel-actions">
							<!--<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>-->
						</div>
					</div>	
					<?php
					$sql2 = "SELECT * FROM notice_list WHERE id='$noticeID'";
		            $r = sql_select($sql2);
		            while($row2=mysqli_fetch_assoc($r)){
					?>
					<div class="panel-body bk-bg-white bk-padding-top-30 bk-padding-bottom-20">
						<form class="form-horizontal form-bordered" action="php/alter-notice-submit.php?noticeID=<?php echo $noticeID;?>" method="post">
							<div class="form-group">											
								<div class="col-md-10">
								<div class="form-group">
									<label class="col-md-3 control-label" for="text-input">标题</label>
									<div class="col-md-9">
										<input type="text" id="text-input" name="theme" class="form-control" placeholder="<?php echo $row2['theme']?>">
										<span class="help-block">这里填写公告标题</span>
									</div>
								</div>
								<textarea name="content" data-plugin-markdown-editor rows="20" placeholder="在这里编辑..."><?php echo $row2['contents']?></textarea>
								</div>
								<div class="col-md-2">
									<div class="checkbox-custom checkbox-default bk-margin-top-10">
										<input id="RememberMe" name="rememberme" type="checkbox">
										<label for="RememberMe">公开</label>
									</div>
									<hr/>
									<button type="submit" class="btn btn-primary">发布</button>
								</div>
							</div>										
						</form>
					</div>
					<?php }?>
				</div>
			</div>
		</div> 
	    
	    <div class="clearfix"></div>		
	<?php
	    }
	}
	else{
	?>
	<script>window.alert("请先登录");</script>
	<meta http-equiv="refresh" content="0;url=http://yiban.ives.ltd/page-login-admins.html" />
	<?php
	}
	?>
		
		<!-- start: JavaScript-->
		
		<!-- Vendor JS-->				
		<script src="assets/vendor/js/jquery.min.js"></script>
		<script src="assets/vendor/js/jquery-2.1.1.min.js"></script>
		<script src="assets/vendor/js/jquery-migrate-1.2.1.min.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/vendor/skycons/js/skycons.js"></script>
		<script src="assets/vendor/js/pace.min.js"></script>
		
		<!-- Plugins JS-->
		<script src="assets/plugins/moment/js/moment.min.js"></script>	
		<script src="assets/plugins/fullcalendar/js/fullcalendar.min.js"></script>
		<script src="assets/plugins/summernote/js/summernote.js"></script>
		<script src="assets/plugins/bootstrap-markdown/js/bootstrap-markdown.js"></script>
		<script src="assets/plugins/bootstrap-markdown/js/markdown.js"></script>
		<script src="assets/plugins/bootstrap-markdown/js/to-markdown.js"></script>
		<script src="assets/plugins/sparkline/js/jquery.sparkline.min.js"></script>
		
		<!-- Theme JS -->		
		<script src="assets/js/jquery.mmenu.min.js"></script>
		<script src="assets/js/core.min.js"></script>
		
		<!-- Pages JS -->
		<script src="assets/js/pages/form-editors.js"></script>
		<script src="assets/js/pages/form-elements.js"></script>
		
		<!-- end: JavaScript-->
	</body>
</html>