<!DOCTYPE html>
<html lang="en">
<?php include("php/dbConnector.php");?>
<head>

	<!-- Basic -->
	<meta charset="UTF-8" />

	<title>eBook | 公告板</title>
  
	<!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	
	<!-- Import google fonts -->
    <link href='http://fonts.useso.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>
    
	<!-- Favicon and touch icons -->
	<link rel="shortcut icon" href="assets/ico/favicon.ico" type="image/x-icon" />
	<link rel="apple-touch-icon" href="assets/ico/apple-touch-icon.png" />
	<link rel="apple-touch-icon" sizes="57x57" href="assets/ico/apple-touch-icon-57x57.png" />
	<link rel="apple-touch-icon" sizes="72x72" href="assets/ico/apple-touch-icon-72x72.png" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/ico/apple-touch-icon-76x76.png" />
	<link rel="apple-touch-icon" sizes="114x114" href="assets/ico/apple-touch-icon-114x114.png" />
	<link rel="apple-touch-icon" sizes="120x120" href="assets/ico/apple-touch-icon-120x120.png" />
	<link rel="apple-touch-icon" sizes="144x144" href="assets/ico/apple-touch-icon-144x144.png" />
	<link rel="apple-touch-icon" sizes="152x152" href="assets/ico/apple-touch-icon-152x152.png" />
	
    <!-- start: CSS file-->
	
	<!-- Vendor CSS-->
	<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/vendor/skycons/css/skycons.css" rel="stylesheet" />
	<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="assets/vendor/css/pace.preloader.css" rel="stylesheet" />
	
	<!-- Plugins CSS-->
	<link href="assets/plugins/bootkit/css/bootkit.css" rel="stylesheet" />
	<link href="assets/plugins/jquery-ui/css/jquery-ui-1.10.4.min.css" rel="stylesheet" />					
	
	<!-- Theme CSS -->
	<link href="assets/css/jquery.mmenu.css" rel="stylesheet" />
	
	<!-- Page CSS -->		
	<link href="assets/css/style.css" rel="stylesheet" />
	<link href="assets/css/add-ons.min.css" rel="stylesheet" />
	
	<!-- end: CSS file-->	
    
	
	<!-- Head Libs -->
	<script src="assets/plugins/modernizr/js/modernizr.js"></script>
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->		
	
</head>

<body>
    <?php
    $sql = "SELECT * FROM notice_list ORDER BY date DESC";
    $r = sql_select($sql);
    if($r){
        while($row=mysqli_fetch_assoc($r)){
    ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default bk-bg-white">                        
				<div class="panel-heading bk-bg-white">
					<h6><a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a><i class="fa fa-font red"></i><b>主题：</b><?php echo $row["theme"];?>&nbsp;&nbsp;&nbsp;&nbsp;<b style="text-algin:right">日期：</b><?php echo $row["date"]?></h6>
					<div class="panel-actions">
						<a href="#" class="btn-minimize"><i class="fa fa-caret-up"></i></a>
					</div>
				</div>
				<div class="panel-body" style="display: none;">
				    <div class="md-preview" data-provider="markdown-preview" style="resize: none;">
				        <?php echo $row["contents"];?>
				    </div>
				</div>
			</div>
        </div>
    </div>
    <?php
        }
    }
    ?>
    <div class="clearfix"></div>		
	<!-- start: JavaScript-->
	
	<!-- Vendor JS-->				
	<script src="assets/vendor/js/jquery.min.js"></script>
	<script src="assets/vendor/js/jquery-2.1.1.min.js"></script>
	<script src="assets/vendor/js/jquery-migrate-1.2.1.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/skycons/js/skycons.js"></script>	
	<script src="assets/vendor/js/pace.min.js"></script>
	
	<!-- Plugins JS-->
	<script src="assets/plugins/jquery-ui/js/jquery-ui-1.10.4.min.js"></script>		
	<script src="assets/plugins/sparkline/js/jquery.sparkline.min.js"></script>
	
	<!-- Theme JS -->		
	<script src="assets/js/jquery.mmenu.min.js"></script>
	<script src="assets/js/core.min.js"></script>
	
	<!-- Pages JS -->
	<script src="assets/js/pages/typography.js"></script>
	
	<!-- end: JavaScript-->
</body>