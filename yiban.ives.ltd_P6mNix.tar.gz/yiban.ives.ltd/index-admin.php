<!DOCTYPE html>
<html lang="en">
<?php
session_start();
include("php/dbConnector.php");
?>
<head>

	<!-- Basic -->
	<meta charset="UTF-8" />

	<title>eBook-DHU易购书-系统管理员页面</title>
 
	<!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	
	<!-- Import google fonts -->
    <link href='http://fonts.useso.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>
    
	<!-- Favicon and touch icons -->
	<link rel="shortcut icon" href="assets/ico/favicon.ico" type="image/x-icon" />
	<link rel="apple-touch-icon" href="assets/ico/apple-touch-icon.png" />
	<link rel="apple-touch-icon" sizes="57x57" href="assets/ico/apple-touch-icon-57x57.png" />
	<link rel="apple-touch-icon" sizes="72x72" href="assets/ico/apple-touch-icon-72x72.png" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/ico/apple-touch-icon-76x76.png" />
	<link rel="apple-touch-icon" sizes="114x114" href="assets/ico/apple-touch-icon-114x114.png" />
	<link rel="apple-touch-icon" sizes="120x120" href="assets/ico/apple-touch-icon-120x120.png" />
	<link rel="apple-touch-icon" sizes="144x144" href="assets/ico/apple-touch-icon-144x144.png" />
	<link rel="apple-touch-icon" sizes="152x152" href="assets/ico/apple-touch-icon-152x152.png" />
	
    <!-- start: CSS file-->
	
	<!-- Vendor CSS-->
	<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/vendor/skycons/css/skycons.css" rel="stylesheet" />
	<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="assets/vendor/css/pace.preloader.css" rel="stylesheet" />
	
	<!-- Plugins CSS-->
	<link href="assets/plugins/jquery-ui/css/jquery-ui-1.10.4.min.css" rel="stylesheet" />	
	<link href="assets/plugins/scrollbar/css/mCustomScrollbar.css" rel="stylesheet" />
	<link href="assets/plugins/bootkit/css/bootkit.css" rel="stylesheet" />
	<link href="assets/plugins/magnific-popup/css/magnific-popup.css" rel="stylesheet" />
	<link href="assets/plugins/fullcalendar/css/fullcalendar.css" rel="stylesheet" />
	<link href="assets/plugins/jqvmap/jqvmap.css" rel="stylesheet" />
	
	<!-- Theme CSS -->
	<link href="assets/css/jquery.mmenu.css" rel="stylesheet" />
	
	<!-- Page CSS -->		
	<link href="assets/css/style.css" rel="stylesheet" />
	<link href="assets/css/add-ons.min.css" rel="stylesheet" />
	
	<!-- end: CSS file-->	
    
	
	<!-- Head Libs -->
	<script src="assets/plugins/modernizr/js/modernizr.js"></script>
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->		
	
</head>

<body>
<!--书库管理员侧边栏选项-->
	<?php
	if(isset($_SESSION["adminID"])){
		$adminID = $_SESSION["adminID"];
		$sql = "SELECT * FROM admin_information WHERE username='$adminID'";
		$result = mysqli_query($conn,$sql);
		while($row=mysqli_fetch_assoc($result)){
	?>
		<!-- Start: Header -->
		<div class="navbar" role="navigation">
			<div class="container-fluid container-nav">
				<!-- Navbar Action -->
				<ul class="nav navbar-nav navbar-actions navbar-left">
					<li class="visible-md visible-lg"><a href="#" id="main-menu-toggle"><i class="fa fa-th-large"></i></a></li>
					<li class="visible-xs visible-sm"><a href="#" id="sidebar-menu"><i class="fa fa-navicon"></i></a></li>			
				</ul>
				<!-- Navbar Left -->
				<div class="navbar-left"></div>
				<div class="navbar-right">
				    <div class="userbox">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<div class="profile-info">
								<span class="name"><?php echo $row["username"];?></span>
								<span class="role"><i class="fa fa-circle bk-fg-success"></i>admin</span>
							</div>
						
							<i class="fa custom-caret"></i>
						</a>
						<div class="dropdown-menu">
							<ul class="list-unstyled">
								<li class="dropdown-menu-header bk-bg-white bk-margin-top-15">						
									<div class="progress progress-xs  progress-striped active">
										<div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
											60%
										</div>
									</div>							
								</li>	
								<li>
									<a href="admin-info.php?identity=<?=$row["identity"]?>" target="right"><i class="fa fa-wrench"></i> 个人信息</a>
								</li>
								<li>
									<a href="page-login-admin.html"><i class="fa fa-power-off"></i> 退出</a>
								</li>
							</ul>
						</div>
					</div>
					<!-- End Userbox -->
				</div>
				<!-- End Navbar Right -->
			</div>		
		</div>
		<!-- End: Header -->
		
		<!-- Start: Content -->
		<div class="container-fluid content">	
			<div class="row">
			
				<!-- Sidebar -->
				<div class="sidebar">
					<div class="sidebar-collapse">
						<!-- Sidebar Header Logo-->
						<div class="sidebar-header">
							<img src="assets/img/logo.png" class="img-responsive" alt="" />
						</div>
						<div class="sidebar-menu">						
							<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-sidebar">
									<div class="panel-body text-center">								
										<div class="flag">
											<img src="assets/img/flags/DHU.png" class="img-flags" alt="" />
										</div>
									</div>
									<li class="active">
										<a href="welcome.html" target="right">
											<i class="fa fa-laptop" aria-hidden="true"></i><span>首页</span>
										</a>
									</li>
									<li>
										<a href="book-info-upload.html" target="right">
											<i class="fa fa-edit" aria-hidden="true"></i><span>更新书单列表</span>
										</a>
									</li>
									<li>
										<a href="purchase-count.php" target="right">
											<i class="fa fa-table" aria-hidden="true"></i><span>书籍购买情况</span>
										</a>
									</li>
									<li>
										<a href="add-notice.html" target="right">
											<i class="fa fa-bell" aria-hidden="true"></i><span>发布系统公告</span>
										</a>
									</li>
									<li>
										<a href="notice-list.html" target="right">
											<i class="fa fa-bars" aria-hidden="true"></i><span>历史公告管理</span>
										</a>
									</li>
									<li>
										<a href="add-admin.php" target="right">
											<i class="fa fa-group" aria-hidden="true"></i><span>管理员群组</span>
										</a>
									</li>
								</ul>
							</nav>
						</div>
						<!--班级管理员侧边栏选项结束-->
						<!-- End Sidebar Menu-->
					</div>
					<!-- Sidebar Footer-->
					<div class="sidebar-footer">
						<div class="small-chart-visits">
							<div class="small-chart" id="sparklineLineVisits"></div>
							<div class="small-chart-info"></div>

						</div>
						<ul class="sidebar-terms bk-margin-top-10">

						</ul>
					</div>
					<!-- End Sidebar Footer-->
				</div>
				<!-- End Sidebar -->
						
				<!-- Main Page -->
				<div class="main">
					<!-- Page Header -->
					<div class="page-header">
						<div class="pull-left">
							<ol class="breadcrumb visible-sm visible-md visible-lg">
								<li><a href="index.php"><i class="icon fa fa-home"></i>首页</a></li>
								<li class="active"><i class="fa fa-laptop"></i>当前位置</li>
							</ol>
						</div>
						<div class="pull-right">
							<h2>Welcome</h2>
						</div>
					</div>
					<!-- End Page Header -->
                <iframe id="bi_iframe" src="welcome.html"  width="100%" height="630px" name="right" frameborder="0" scrolling="auto"></iframe>
			</div>
		</div><!--/container-->
		
		
		<div class="clearfix"></div>		

	<!--if session exist end-->
	
	<!--if session not exist-->
	<?php
	    }
	}
	else{
	?>
	    <!-- Start: Header -->
		<div class="navbar" role="navigation">
			<div class="container-fluid container-nav">
				<!-- Navbar Action -->
				<ul class="nav navbar-nav navbar-actions navbar-left">
					<li class="visible-md visible-lg"><a href="#" id="main-menu-toggle"><i class="fa fa-th-large"></i></a></li>
					<li class="visible-xs visible-sm"><a href="#" id="sidebar-menu"><i class="fa fa-navicon"></i></a></li>			
				</ul>
				<!-- Navbar Left -->
				<div class="navbar-left"></div>
				<div class="navbar-right">
				    <div class="userbox">
				        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<div class="profile-info">
								<span class="name">未登录！</span>
								<span class="role"><i class="fa fa-circle bk-fg-success"></i>未登录</span>
							</div>
						
							<i class="fa custom-caret"></i>
						</a>
						<div class="dropdown-menu">
							<ul class="list-unstyled">
								<li class="dropdown-menu-header bk-bg-white bk-margin-top-15">						
									<div class="progress progress-xs  progress-striped active">
										<div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
											60%
										</div>
									</div>							
								</li>	
								<li>
									<a href="page-login.html"><i class="fa fa-power-off"></i> 去登录/注册</a>
									<a href="page-login-admin.html"><i class="fa fa-power-off"></i> 书库管理员登录</a>
								</li>
							</ul>
						</div>
					</div>
					<!-- End Userbox -->
				</div>
				<!-- End Navbar Right -->
			</div>		
		</div>
		<!-- End: Header -->
		
		<!-- Start: Content -->
		<div class="container-fluid content">	
			<div class="row">
			
				<!-- Sidebar -->
				<div class="sidebar">
					<div class="sidebar-collapse">
						<!-- Sidebar Header Logo-->
						<div class="sidebar-header">
							<img src="assets/img/logo.png" class="img-responsive" alt="" />
						</div>
						<!-- Sidebar Menu-->
						<div class="sidebar-menu">						
							<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-sidebar">
									<div class="panel-body text-center">								
										<div class="flag">
											<img src="assets/img/flags/DHU.png" class="img-flags" alt="" />
										</div>
									</div>
									<li class="active">
										<a href="page-404.html" target="right">
											<i class="fa fa-laptop" aria-hidden="true"></i><span>首页</span>
										</a>
									</li>
								</ul>
							</nav>
						</div>
						<!-- End Sidebar Menu-->
					</div>
					<!-- Sidebar Footer-->
					<div class="sidebar-footer">
						<div class="small-chart-visits">
							<div class="small-chart" id="sparklineLineVisits"></div>
							<div class="small-chart-info"></div>

						</div>
						<ul class="sidebar-terms bk-margin-top-10">

						</ul>
					</div>
					<!-- End Sidebar Footer-->
				</div>
				<!-- End Sidebar -->
						
				<!-- Main Page -->
				<div class="main">
					<!-- Page Header -->
					<div class="page-header">
						<div class="pull-left">
							<ol class="breadcrumb visible-sm visible-md visible-lg">
								<li><a href="index.php"><i class="icon fa fa-home"></i>首页</a></li>
								<li class="active"><i class="fa fa-laptop"></i>当前位置</li>
							</ol>
						</div>
						<div class="pull-right">
							<h2>Welcome</h2>
						</div>
					</div>
					<!-- End Page Header -->
                <iframe id="bi_iframe" src="page-404.html" name="right" width="100%" height="630px" scrolling="auto" frameborder="0" marginheight="0" marginwidth="0"></iframe>
			</div>
		</div><!--/container-->
		
		
		<!--<div class="clearfix"></div>-->
	<?php
	}
	?>
	<!--if session not exist end-->
		
		<!-- start: JavaScript-->
		
		<!-- Vendor JS-->				
		<script src="assets/vendor/js/jquery.min.js"></script>
		<script src="assets/vendor/js/jquery-2.1.1.min.js"></script>
		<script src="assets/vendor/js/jquery-migrate-1.2.1.min.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/vendor/skycons/js/skycons.js"></script>
		<script src="assets/vendor/js/pace.min.js"></script>
		
		<!-- Plugins JS-->
		<script src="assets/plugins/jquery-ui/js/jquery-ui-1.10.4.min.js"></script>
		<script src="assets/plugins/scrollbar/js/jquery.mCustomScrollbar.concat.min.js"></script>
		<script src="assets/plugins/bootkit/js/bootkit.js"></script>
		<script src="assets/plugins/magnific-popup/js/magnific-popup.js"></script>
		<script src="assets/plugins/moment/js/moment.min.js"></script>	
		<script src="assets/plugins/fullcalendar/js/fullcalendar.js"></script>
		<script src="assets/plugins/flot/js/jquery.flot.min.js"></script>
		<script src="assets/plugins/flot/js/jquery.flot.pie.min.js"></script>
		<script src="assets/plugins/flot/js/jquery.flot.resize.min.js"></script>
		<script src="assets/plugins/flot/js/jquery.flot.stack.min.js"></script>
		<script src="assets/plugins/flot/js/jquery.flot.time.min.js"></script>
		<script src="assets/plugins/flot-tooltip/js/jquery.flot.tooltip.js"></script>
		<script src="assets/plugins/chart-master/js/Chart.js"></script>
		<script src="assets/plugins/jqvmap/jquery.vmap.js"></script>
		<script src="assets/plugins/jqvmap/data/jquery.vmap.sampledata.js"></script>
		<script src="assets/plugins/jqvmap/maps/jquery.vmap.world.js"></script>
		<script src="assets/plugins/sparkline/js/jquery.sparkline.min.js"></script>
		
		<!-- Theme JS -->		
		<script src="assets/js/jquery.mmenu.min.js"></script>
		<script src="assets/js/core.min.js"></script>
		
		<!-- Pages JS -->
		<script src="assets/js/pages/index.js"></script>
		
		<!-- end: JavaScript-->
	</div>
	</body>
	
</html>