<!DOCTYPE html>
<html lang="en">
<?php session_start();include("php/dbConnector.php");?>
<head>

	<!-- Basic -->
	<meta charset="UTF-8" />

	<title>eBook | 管理员群组</title>

	<!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	
	<!-- Import google fonts -->
    <link href='http://fonts.useso.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>
    
	<!-- Favicon and touch icons -->
	<link rel="shortcut icon" href="assets/ico/favicon.ico" type="image/x-icon" />
	<link rel="apple-touch-icon" href="assets/ico/apple-touch-icon.png" />
	<link rel="apple-touch-icon" sizes="57x57" href="assets/ico/apple-touch-icon-57x57.png" />
	<link rel="apple-touch-icon" sizes="72x72" href="assets/ico/apple-touch-icon-72x72.png" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/ico/apple-touch-icon-76x76.png" />
	<link rel="apple-touch-icon" sizes="114x114" href="assets/ico/apple-touch-icon-114x114.png" />
	<link rel="apple-touch-icon" sizes="120x120" href="assets/ico/apple-touch-icon-120x120.png" />
	<link rel="apple-touch-icon" sizes="144x144" href="assets/ico/apple-touch-icon-144x144.png" />
	<link rel="apple-touch-icon" sizes="152x152" href="assets/ico/apple-touch-icon-152x152.png" />
	
    <!-- start: CSS file-->
	
	<!-- Vendor CSS-->
	<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="assets/vendor/skycons/css/skycons.css" rel="stylesheet" />
	<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="assets/vendor/css/pace.preloader.css" rel="stylesheet" />
	
	<!-- Plugins CSS-->
	<link href="assets/plugins/bootkit/css/bootkit.css" rel="stylesheet" />
	<link href="assets/plugins/jquery-ui/css/jquery-ui-1.10.4.min.css" rel="stylesheet" />					
	<link href="assets/plugins/editable/css/bootstrap-editable.css" rel="stylesheet" />
	<link href="assets/plugins/bootkit/css/bootkit.css" rel="stylesheet" />
	<link href="assets/plugins/select2/select2.css" rel="stylesheet" />
	<link href="assets/plugins/jquery-datatables-bs3/css/datatables.css" rel="stylesheet" />
	<link href="assets/plugins/magnific-popup/css/magnific-popup.css" rel="stylesheet" />
	
	<!-- Theme CSS -->
	<link href="assets/css/jquery.mmenu.css" rel="stylesheet" />
	
	<!-- Page CSS -->		
	<link href="assets/css/style.css" rel="stylesheet" />
	<link href="assets/css/add-ons.min.css" rel="stylesheet" />
	
	<!-- end: CSS file-->	
    
	
	<!-- Head Libs -->
	<script src="assets/plugins/modernizr/js/modernizr.js"></script>
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->		
	
</head>

<body>
    <?php
	if(isset($_SESSION["adminID"])){
		$adminID = $_SESSION["adminID"];
		$sql = "SELECT * FROM admin_information WHERE username='$adminID'";
		$result = mysqli_query($conn,$sql);
		while($row=mysqli_fetch_assoc($result)){
		    if($adminID=="s_admin"){
	?>
    <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="panel panel-default bk-bg-white">
				<div class="panel-heading bk-bg-white">
					<h6><i class="fa fa-table red"></i><span class="break"></span>管理员信息列表</h6>							
					<div class="panel-actions">
					    <a href="#" class="btn-minimize"><i class="fa fa-caret-down"></i></a>
					</div>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-sm-6">
							<div class="bk-margin-bottom-10">
							</div>
						</div>
					</div>
					<table class="table table-bordered table-striped mb-none" id="datatable-editable">
						<thead>
							<tr>
							    <th>用户名</th>
								<th>密码</th>
								<th>ID</th>
								<th>操作</th>
							</tr>
						</thead>
						<tbody id="test-editable">
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	
    <div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default bk-bg-white">
				<div class="panel-heading bk-bg-white">
					<h6><i class="fa fa-pencil red"></i>添加管理员信息</h6>
					<div class="panel-actions">
					</div>
				</div>
				<form action="php/admin-info-submit.php" method="post">
				<div class="panel-body">
					<div style="float: right; margin-bottom: 10px">
						<div class="checkbox-custom checkbox-default">
							<button class="btn btn-primary" type="submit">提交</button>
						</div>
					</div>
					<table id="user" class="table table-bordered table-striped" style="clear: both">
						<tbody>
							<tr>         
								<td width="35%">用户名</td>
								<td width="65%"><input type="text" name="user" class="form-control" placeholder="必填（不能重复）" required /></td>
							</tr>
							<tr>         
								<td>密码</td>
								<td><input type="password" name="pwd" class="form-control" placeholder="必填" required /></td>
							</tr>  
							<tr>         
								<td>重复密码</td>
								<td><input type="password" name="repwd" class="form-control" placeholder="必填" required /></td>
							</tr>
						</tbody>
					</table>
				</div>
				</form>
			</div>
		</div>
	</div>
	<div class="clearfix"></div>
	<?php
		    }
		    else{
		        ?>
		        <script>window.alert("你暂时没有权限查看哦（!_!）");history.go(-1);</script>
		        <?php
		    }
	    }
	}
	else{
	?>
	    <p><a href="http://yiban.ives.ltd/page-login-admin.html">请先登录</a></p>
	<?php
	}
	?>
	<!-- start: JavaScript-->
	<script src="assets/plugins/modernizr/js/modernizr.js"></script>
	<script src="assets/plugins/jquery/js/jquery.js"></script>
	<script type="text/javascript">
	$.get("php/admin-list.php",function(data){
        var jsonObj=JSON.parse(data);
        //alert(jsonObj);
        var listHTML = '';
        for (var i=0; i<jsonObj.length; i++){
            listHTML += '<tr class="gradeX">' +
            '<td>'+jsonObj[i].username+'</td>' + 
            '<td>'+jsonObj[i].password+'</td>' +
            '<td>'+jsonObj[i].userid+'</td>' +
            '<td><button type="button" class="bk-margin-5 btn btn-danger"><a href="php/move-from-adminlist.php?adminID='+jsonObj[i].userid+'"><i class="fa fa-trash-o"></i></a></button></td>' +
            '</tr>';
        }
        document.getElementById("test-editable").innerHTML = listHTML;
    });
	</script>
	<!-- Vendor JS-->				
	<script src="assets/vendor/js/jquery.min.js"></script>
	<script src="assets/vendor/js/jquery-2.1.1.min.js"></script>
	<script src="assets/vendor/js/jquery-migrate-1.2.1.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/skycons/js/skycons.js"></script>
	<script src="assets/vendor/js/pace.min.js"></script>
	
	<!-- Plugins JS-->
	<script src="assets/plugins/jquery-ui/js/jquery-ui-1.10.4.min.js"></script>		
	<script src="assets/plugins/mockjax/js/jquery.mockjax.min.js"></script>
	<script src="assets/plugins/editable/js/bootstrap-editable.min.js"></script>
	<script src="assets/plugins/moment/js/moment.min.js"></script>
	<script src="assets/plugins/editable/inputs-ext/typeaheadjs/typeaheadjs.min.js"></script>
	<script src="assets/plugins/editable/inputs-ext/address/address.min.js"></script>
	<script src="assets/plugins/select2/js/select2.min.js"></script>
	<script src="assets/plugins/select2/select2.js"></script>	
	<script src="assets/plugins/sparkline/js/jquery.sparkline.min.js"></script>
	<script src="assets/plugins/jquery-datatables/media/js/jquery.dataTables.js"></script>
	<script src="assets/plugins/jquery-datatables-bs3/js/datatables.js"></script>
	<script src="assets/plugins/magnific-popup/js/magnific-popup.js"></script>
	<!-- Theme JS -->		
	<script src="assets/js/jquery.mmenu.min.js"></script>
	<script src="assets/js/core.min.js"></script>
	
	<!-- Pages JS -->
	<script src="assets/js/pages/form-x-editable-demo.js"></script>
	<script src="assets/js/pages/form-x-editable.js"></script>
	<script src="assets/js/pages/table-editable.js"></script>
	<!-- end: JavaScript-->
</body>
</html>