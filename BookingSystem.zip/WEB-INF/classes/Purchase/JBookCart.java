// Java Document
package Purchase;
import java.sql.*;
public class JBookCart{
	String sdbdriver;
	Connection con;
	ResultSet rs;
	String Err;
	public String getErr(){ return Err; }
	//
	public JBookCart()
	{
		sdbdriver = "sun.jdbc.odbc.JdbcOdbcDriver";
		con = null;
		rs = null;
		Err = "";
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		}
		catch(Exception e){ Err = Err + "Database Error" + e.getMessage(); }
	}
	//
	public String addItem(String Username,String BookID,String BookName,String Price)
	{
		String status = "null";
		try
		{
			con = DriverManager.getConnection("jdbc:odbc:BookingSystem","sa","admin2020");
			Statement stmt = con.createStatement();
			int i = stmt.executeUpdate("INSERT INTO BuyBook(Username,BookID,BookName,Price) VALUE('"+Username+"','"+BookID+"','"+BookName+"','"+Price+"')");
			status = "UPDATE BuyBook Success!";
			
		}
		catch(SQLException sqlexception)
		{
			Err = Err + "executeQuery error1:" + sqlexception.getMessage();
		}
		return status;
	}
	//
	public void removeItem(String BookID,String Username)
	{
		try
		{
			con = DriverManager.getConnection("jdbc:odbc:BookingSystem","sa","admin2020");
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM BuyBook WHERE BookID='"+BookID+"'");
			if(rs.next())
			{
				stmt.execute("DELETE FROM BuyBook WHERE BookID='"+BookID+"' AND Username='"+Username+"'");
			}
		}
		catch(SQLException sqlexception)
		{
			Err = Err + "executeQuery error2:" + sqlexception.getMessage();
		}
	}
	//
	public String removeBook(String BookID)
	{
		String status = "null";
		try
		{
			con = DriverManager.getConnection("jdbc:odbc:BookingSystem","sa","admin2020");
			Statement stmt = con.createStatement();
			int i = stmt.executeUpdate("UPDATE BookList SET num=num-1 WHERE BookID='"+BookID+"'");
			status = "UPDATE BookList Success!";
			
		}
		catch(SQLException sqlexception)
		{
			Err = Err + "executeQuery error3:" + sqlexception.getMessage();
		}
		return status;
	}
	//
	public double getCost(String Username)
	{
		double totalcost = 0.00;
		try
		{
			con = DriverManager.getConnection("jdbc:odbc:BookingSystem","sa","admin2020");
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM BuyBook WHERE Username='"+Username+"'");
			while(rs.next())
			{
				double d;
				d = Double.parseDouble(rs.getString("Price"));
				totalcost += d;
			}
		}
		catch(Exception e)
		{
			Err = Err + "Exception4:" + e.getMessage();
		}
		return totalcost;
	}
	//
	public int getNumOfItems(String BookID)
	{
		int num = 0;
		try
		{
			con = DriverManager.getConnection("jdbc:odbc:BookingSystem","sa","admin2020");
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM BuyBook WHERE BookID='"+BookID+"'");
			while(rs.next())
			{
				num += 1;
			}
		}
		catch(Exception e)
		{
			Err = Err + "Exception5:" + e.getMessage();
		}
		return num;
	}
	//
	public void closeconn()
	{
		try
		{
			if(rs != null){ rs.close(); }
			if(con != null){ con.close(); }
		}
		catch(SQLException sqlexception){}
	}
}