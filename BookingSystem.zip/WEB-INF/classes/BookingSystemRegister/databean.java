//Java Document
//databean.java Document
package BookingSystemRegister;
import java.sql.*;
public class databean
{
	String sdbdriver;
	String connstr;
	Connection conn;
	ResultSet rs;
	String Err;
	public String getErr(){ return Err; }
	//
	public databean()
	{
		sdbdriver = "sun.jdbc.odbc.JdbcOdbcDriver";
		connstr = "jdbc:odbc:BookingSystem";
		conn = null;
		rs = null;
		Err = "";
		try
		{
			Class.forName(sdbdriver);
		}
		catch(ClassNotFoundException classnotfoundexception)
		{
			Err = "Datebase error 1:" + classnotfoundexception.getMessage();
		}
	}
	//
	public ResultSet executeQuery(String s)
	{
		rs = null;
		try
		{
			conn = DriverManager.getConnection(connstr,"sa","admin2020");
			Statement statement = conn.createStatement();
			rs = statement.executeQuery(s);
		}
		catch(SQLException sqlexception)
		{
			Err = Err + "executeQuery error1:" + sqlexception.getMessage();
		}
		return rs;
	}
	//
	public int ExecuteUpdate(String s)
	{
		int i = 0;
		try
		{
			conn = DriverManager.getConnection(connstr,"sa","admin2020");
			Statement statement = conn.createStatement();
			i = statement.executeUpdate(s);
		}
		catch(SQLException sqlexception)
		{
			if(i==0)
			{
			    Err = Err + "executeQuery error2:" + sqlexception.getMessage();
			}
		}
		return i;
	}
	//
	public boolean checkAccount(String userstr,String pwdstr)
	{
		boolean flag = false;
		String s2 = "SELECT * FROM Register_info WHERE Username='" + userstr + "' AND Password='" + pwdstr + "'";
		try
		{
            ResultSet resultset = executeQuery(s2);
			if(resultset.next()){ flag = true; }
			rs.close();
		}
		catch(Exception exception){}
		return flag;
	}
	//
	public void closeconn()
	{
		try
		{
			if(rs != null){ rs.close(); }
			if(conn != null){ closeconn(); }
		}
		catch(SQLException sqlexception){}
	}
}
